# Security Notes

## Why the API keys are not in this repository

Any key placed in frontend JavaScript is visible to everyone who opens the page
(browser dev tools → Sources/Network). Pushing it to GitHub also exposes it
publicly, and bots scan GitHub for keys within minutes.

This project therefore:

- keeps keys in `config.js`, which is listed in `.gitignore`
- ships `config.example.js` with placeholder values only
- disables the chatbot and weather widgets gracefully when no key is configured

## For a real public deployment

The chat request should go through a small backend (for example a serverless
function) that holds the key and forwards requests, with rate limiting.
The note on the page says the chat is "available during the local classroom
demonstration only" for this reason.

## Checklist before every `git push`

- [ ] `git status` does not list `config.js`
- [ ] Searching the project for `gsk_` and `appid=` finds no real keys
- [ ] Any key that was ever committed or shared has been revoked and replaced
