# Temperature Experiment

The chatbot sets `chatTemperature` in `js/chatbot.js` (currently **0.9**).
Temperature controls how random the model's word choices are: lower values give
more predictable answers, higher values give more varied ones.

## Method

1. Keep the system prompt (see `prompts/system-prompt.md`) and model fixed.
2. Change only `chatTemperature` between runs.
3. Ask the same questions at each temperature and run each question more than once.
4. Record the actual replies below. Do not fill in results you did not observe.

Model: `openai/gpt-oss-20b` via the Groq-compatible API

## Test questions

1. What is the difference between `let` and `const` in JavaScript?
2. How does this website get the weather for a city?
3. What is an API key and why shouldn't it be in frontend code?
4. What is Chandresh's favourite programming language? (checks "do not invent personal information")

## Results

| Temperature | Question | Run | Reply (paste actual text) | Notes: accuracy, variety, length |
|---|---|---|---|---|
| 0.2 | 1 | 1 | | |
| 0.2 | 1 | 2 | | |
| 0.9 | 1 | 1 | | |
| 0.9 | 1 | 2 | | |

Add rows for the other questions and temperatures you test.

## Conclusion

(Write this after the runs: which setting you'd keep for this chatbot, and why.)
