# Personal Portfolio Website with AI Chatbot

## About the Project

This project is a personal portfolio website designed to showcase personal information, skills, and projects. It includes interactive features such as a dark/light mode toggle, a weather application, and an AI-powered chatbot.

The website combines frontend web development with API integration to provide an interactive user experience.

## Features

- **Personal Portfolio:** Presents personal information and showcases projects.
- **Dark/Light Mode:** Allows users to switch between dark and light themes.
- **Weather Application:** Fetches current weather information for a city using the OpenWeatherMap API.
- **AI Chatbot:** Provides AI-generated responses to questions about web development, APIs, and projects.
- **Input Validation:** Checks whether a city name or chat message has been entered.
- **Error Handling:** Displays messages when weather data or AI responses cannot be retrieved.
- **Interactive Interface:** Uses JavaScript event listeners to respond to user actions.

## Technologies Used

- HTML — Website structure
- CSS — Styling and visual presentation
- JavaScript — Interactive functionality and API requests
- OpenWeatherMap API — Weather information
- Groq-compatible Chat Completions API — AI chatbot responses

## How It Works

### 1. Theme Toggle

The theme button switches the website between dark and light modes by toggling a CSS class on the page.

### 2. Weather Application

Users enter a city name, and JavaScript sends a request to the OpenWeatherMap API. The application displays the city's name, temperature in Celsius, and weather conditions.

### 3. AI Chatbot

Users enter a question and receive an AI-generated response. The chatbot sends a request to a chat completions API and displays the returned answer. It also handles errors such as rate limits and connectivity problems.

## Project Structure

```text
prompt-engineering-portfolio/
├── index.html
├── config.example.js        # template for local keys (copy to config.js)
├── .gitignore               # keeps config.js out of GitHub
├── css/
│   ├── style.css
│   └── chatbot.css
├── js/
│   ├── script.js            # theme toggle + weather
│   └── chatbot.js           # AI chatbot
├── prompts/
│   └── system-prompt.md     # chatbot system prompt and its versions
├── docs/
│   ├── audit-page.md        # portfolio content audit
│   ├── temperature-experiment.md
│   └── security-notes.md
└── README.md
```

## Prompt Engineering

This project doubles as a prompt-engineering exercise on the chatbot:

- The system prompt is documented in [`prompts/system-prompt.md`](prompts/system-prompt.md).
- The temperature experiment (currently 0.9) is set up in [`docs/temperature-experiment.md`](docs/temperature-experiment.md).
- Content accuracy is checked in [`docs/audit-page.md`](docs/audit-page.md).

## How to Run

1. Download or clone the repository.
2. Copy `config.example.js` to `config.js` and add your own Groq-compatible API key and OpenWeatherMap key. `config.js` is git-ignored.
3. Start a local server in the project folder, for example `python -m http.server 8000`.
4. Open `http://localhost:8000` and test the theme toggle, weather, and chatbot.

Without `config.js`, the page still works, but the chatbot and weather widgets show a "not configured" message.

## Security

- Never commit API keys, passwords, or secret environment files to a public repository.
- Keep private AI API keys on the server, not in frontend JavaScript.
- Restrict and monitor API usage to avoid unauthorized requests.
- Rotate any API key that has already been exposed.

## Future Improvements

- Improve mobile responsiveness and accessibility.
- Add more project details and links to project repositories.
- Improve chatbot responses using accurate portfolio information.
- Add secure backend API integration.

## Author

**Chandresh Sharma**

Engineering student (ID: 25BCON1985).

## License

This project is intended for educational and personal portfolio purposes.
