console.log("Javascript connected");
const button=document.getElementById("themeButton");
button.addEventListener("click",()=>{
    console.log("Button clicked");
    
    document.body.classList.toggle("dark-mode");
    if(document.body.classList.contains("dark-mode")){
        button.textContent="Light Mode";
    }else{
        button.textContent="Dark Mode";
    }
});
const cityInput = document.getElementById("cityInput");
const weatherButton = document.getElementById("weatherButton");
const weatherResult = document.getElementById("weatherResult");
weatherButton.addEventListener("click", getWeather);
async function getWeather() {

    const city = cityInput.value.trim();

    if (!city) {
        weatherResult.textContent = "Please enter a city.";
        return;
    }

    weatherResult.textContent = "Loading weather...";

    if (typeof CONFIG === "undefined" || !CONFIG.weatherApiKey ||
        CONFIG.weatherApiKey === "YOUR_OPENWEATHERMAP_KEY") {
        weatherResult.textContent =
            "Weather is unavailable: no API key configured (see README).";
        return;
    }

    const url =
        `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}` +
        `&appid=${CONFIG.weatherApiKey}&units=metric`;

    try {

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json();

        weatherResult.textContent = "";
        const title = document.createElement("h3");
        title.textContent = data.name;
        const temp = document.createElement("p");
        temp.textContent = `Temperature: ${data.main.temp}°C`;
        const cond = document.createElement("p");
        cond.textContent = `Condition: ${data.weather[0].description}`;
        weatherResult.append(title, temp, cond);

    } catch (error) {

        weatherResult.textContent =
            "Unable to fetch weather. Please try again.";

        console.error(error);
    }
}