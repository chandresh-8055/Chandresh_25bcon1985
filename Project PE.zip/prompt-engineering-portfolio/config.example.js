// Copy this file to config.js and fill in your own keys.
// config.js is listed in .gitignore and must never be committed.
const CONFIG = {
  apiKey: "YOUR_PRIVATE_GROQ_KEY",
  baseUrl: "https://api.groq.com/openai/v1",
  model: "openai/gpt-oss-20b",
  weatherApiKey: "YOUR_OPENWEATHERMAP_KEY"
};
